import React from 'react'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ActivityChart from './AllGraph/Activity'
import BloodPressure from './AllGraph/BloodPressure'
import BodyTemperature from './AllGraph/BodyTemp'
import HeartRate from './AllGraph/HeartRate'
import PastAppointment from './AllGraph/Past'
import HealtConditions from './AllGraph/HealtCondition'
import LabResult from './AllGraph/LabResult'
import SleepPattern from './AllGraph/Sleep_pattern'
import Calories from './AllGraph/Calories';


const Graph = () => {
    return (
        <div className="row">
            <div className="col-12">
                <div className="Graph">
                    <Tabs>
                        <TabList>
                            <Tab>Analytics</Tab>
                            <Tab>Compliance</Tab>
                        </TabList>

                        <TabPanel>
                            <div className="row mb-3">
                                <div className="col-12">
                                    <div className="chart d-flex justify-content-between">
                                        <ActivityChart />
                                        <HeartRate />
                                        <BloodPressure />
                                        <BodyTemperature />
                                        <PastAppointment />
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-8">
                                    <div className="chart healt__conditions d-flex justify-content-between">
                                        <HealtConditions />
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="chart  d-flex justify-content-between">
                                        <LabResult />
                                    </div>
                                    <div className="calories_sleep_div d-flex">
                                       <SleepPattern/>
                                       <Calories />
                                    </div>
                                </div>
                            </div>
                        </TabPanel>
                        <TabPanel>
                            
                        </TabPanel>
                    </Tabs>
                </div>
            </div>
        </div>
    )
}
export default Graph;