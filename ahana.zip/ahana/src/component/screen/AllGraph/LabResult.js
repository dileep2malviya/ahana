import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { fetchdata } from '../../../store/actions';

const LabResult = () => {
    const MYJSONDATA = useSelector((state) => state.document);
    const dispatch = useDispatch();
    const fetchnewdata = () => dispatch(fetchdata());

    useEffect(() => {
        (async () => {
            fetchnewdata();
        })();
    },[]); 
    return (
        <>
            { MYJSONDATA.documentData ? MYJSONDATA.documentData.userdata ?
                <div className="lab_result box_border_radius">
                    <div className="chart_details d-flex justify-content-between">
                        <h4>Lab Result</h4>
                    </div>
                    <div className="row">
                        <div className="col-4 mt-2 ">
                            <div className="show_result">
                                <span className="mb-2">5 August</span>
                                <h5 className="dark_color_red mb-2">Sugar</h5>
                                <p className="mb-2">{MYJSONDATA.documentData.userdata[0].Sugar}</p>
                            </div>

                        </div>
                        <div className="col-4 mt-2 ">
                            <div className="show_result">
                                <span className="mb-2">5 August</span>
                                <h5 className="dark_color_red mb-2">Haemoglobin</h5>
                                <p className="mb-2">{MYJSONDATA.documentData.userdata[0].Haemoglobin}</p>
                            </div>
                        </div>
                        <div className="col-4 mt-2 ">
                            <div className="show_result">
                                <span className="mb-2">5 August</span>
                                <h5 className="dark_color_red mb-2">white blood Cell</h5>
                                <p className="mb-2">{MYJSONDATA.documentData.userdata[0].whitebloodCell}L</p>
                            </div>
                        </div>
                        <div className="col-4 mt-2 ">
                            <div className="show_result">
                                <span className="mb-2">5 August</span>
                                <h5 className="dark_color_red mb-2">Lymohocyle</h5>
                                <p className="mb-2">{MYJSONDATA.documentData.userdata[0].Lymohocyle}</p>
                            </div>
                        </div>
                        <div className="col-4 mt-2 ">
                            <div className="show_result">
                                <span className="mb-2">5 August</span>
                                <h5 className="dark_color_red mb-2">Red Blood Cell</h5>
                                <p className="mb-2">{MYJSONDATA.documentData.userdata[0].RedBloodCell}</p>
                            </div>
                        </div>
                    </div>
                </div> : null : null}
        </>
    )
}
export default LabResult;