import React, { useEffect } from 'react'
import { Bar } from 'react-chartjs-2';
import { defaults } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { fetchdata } from '../../../store/actions';

defaults.font = 2

const ActivityChart = () => {
    const MYJSONDATA = useSelector((state) => state.document);
    const dispatch = useDispatch();
    const fetchnewdata = () => dispatch(fetchdata());

    useEffect(() => {
        (async () => {
            fetchnewdata();
        })();
    }, []);

    return (
        <>
        { MYJSONDATA.documentData ? MYJSONDATA.documentData.userdata ? <div className="box_chart box_border_radius">
            <div className="chart_details d-flex justify-content-between">
                <h4>Activity</h4>
                <select name="" id="">
                    <option value="Week">Week</option>
                    <option value="day">day</option>
                    <option value="Month">Month</option>
                </select>
            </div>
            <Bar
                data={{
                    labels: MYJSONDATA.documentData.userdata[0].activity.labels,
                    datasets: [{
                        data: MYJSONDATA.documentData.userdata[0].activity.datasets[0].data,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        // borderWidth: 1

                    }]
                }}
                height={400}
                width={600}
                option={{
                    maintainAspectRatio: false,
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Value'
                        },
                        min: 0,
                        max: 100,
                        ticks: {
                            // forces step size to be 50 units
                            stepSize: 50
                        }
                    },
                    plugins: {
                        legend: {
                            labels: {
                                // This more specific font property overrides the global property
                                font: {
                                    size: 1
                                }
                            }
                        }
                    }
                }}
            />
         </div> : null : null}
    </>
    )
}
export default ActivityChart;