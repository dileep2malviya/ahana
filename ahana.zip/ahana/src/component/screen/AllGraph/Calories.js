import React, { useEffect } from 'react'


import { Doughnut } from 'react-chartjs-2';
import { defaults } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { fetchdata } from '../../../store/actions';


const Calories = () => {
    const MYJSONDATA = useSelector((state) => state.document);
    const dispatch = useDispatch();
    const fetchnewdata = () => dispatch(fetchdata());

    useEffect(() => {
        (async () => {
            fetchnewdata();
        })();
    }, []);

    return (
        <>
            { MYJSONDATA.documentData ? MYJSONDATA.documentData.userdata ?
            <div className="sleep_box box_border_radius">
                <div className="chart_details d-flex justify-content-between">
                    <h4>Body Temperature</h4>
                </div>
                <Doughnut
                    data={{
                        labels: [
                          'Calories',
                         
                        ],
                        datasets: [{
                          label: 'My First Dataset',
                          data: MYJSONDATA.documentData.userdata[0].Calories,
                          backgroundColor: [
                            '#800000',
                            'grey',
                          ],
                          hoverOffset: 4
                        }]
                      }}

                />
            </div> : null : null }
        </>
    )
}
export default Calories;