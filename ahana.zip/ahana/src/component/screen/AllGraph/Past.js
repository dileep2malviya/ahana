import React from 'react'


import { Bar } from 'react-chartjs-2';
import { defaults } from 'react-chartjs-2';

// Disable animating charts by default.
// defaults.global.animation = false;


const PastAppointment = () => {
    return (
        <div className="box_chart box_border_radius">
            <div className="chart_details d-flex justify-content-between mb-3">
                <h4>Past Appointment</h4>
            </div>
            <div className="time d-flex justify-content-between">
                <p className="mb-0">10AM - 11AM</p>
                <span>2 Sept</span>
            </div>
            <div className="dr_name">
                <p className="mb-0">Dr. <span>Rakesh chavan</span></p>
            </div>
        </div>
    )
}
export default PastAppointment;