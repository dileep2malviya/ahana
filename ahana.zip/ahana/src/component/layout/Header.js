import { logRoles } from "@testing-library/dom";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchdata } from '../../store/actions/index'

const Header = () => {

    const MYJSONDATA = useSelector((state) => state.document);
    console.log(MYJSONDATA, "docmentdata");

    const dispatch = useDispatch();
    const fetchnewdata = () => dispatch(fetchdata());
    useEffect(() => {
        (async () => {
            fetchnewdata();
        })();
    },[]);  


    
    return  (
        <>
        <header>
            <div className="row align-items-center">
                <div className="col-md-4">
                    <div className="left_header header_box d-flex ">
                        <div className="main_heading">
                            <h1>AHANA</h1>
                        </div>
                        <div className="patient_profile d-flex align-items-center pl-3">
                            <p className="mb-0">Patient Profile</p>
                            { MYJSONDATA.documentData ? MYJSONDATA.documentData.userdata ? console.log(MYJSONDATA.documentData.userdata[0].activity.labels, "wertyuioer") : null : null}
                            <span className="p-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                    <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                </svg>
                            </span>
                            <p className="mb-0">Analytics</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-4 ">
                    <div className="medium_header header_box">
                        <input type="text" placeholder="Search" />
                    </div>
                </div>
                <div className="col-md-4 header_box all_notifcation">
                    <div className="notifcation">
                        <ul className="d-flex mb-0 justify-content-between align-items-center">
                            <li className="li_box error_notify">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#ff0000" className="bi bi-info-circle" viewBox="0 0 16 16">
                                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                                </svg>
                            </li>
                            <li className="li_box">
                                <div className='wrapper'>
                                    <div className="icon nav-icon-1">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </div>
                            </li>
                            <li className="li_box msg_notify_box">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-bell-fill" viewBox="0 0 16 16">
                                    <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901z" />
                                </svg>
                                <div className="message_notify">
                                    4
                                </div>
                            </li>
                            <li className="li_box notification_box d-flex">
                                <div className="profile_image">
                                    <img src={process.env.PUBLIC_URL + '/profile_pic.jpg'} alt="profile Image" />
                                </div>
                                <p className="p-3 mb-0">dr.Raquel</p>
                                <span className="arrow">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-chevron-down" viewBox="0 0 16 16">
                                        <path fillRule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z" />
                                    </svg>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header >
        </>
    )
}
export default Header;