import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { fetchdata } from '../../store/actions';


const HeaderBottom = () => {
    const MYJSONDATA = useSelector((state) => state.document);
    const dispatch = useDispatch();
    const fetchnewdata = () => dispatch(fetchdata());

    const [data, setData] = useState([])



    useEffect(() => {
        (async () => {
            setData(MYJSONDATA)
            fetchnewdata();
        })();
    },[]); 

   
    return  (
        <>
        { MYJSONDATA.documentData ? MYJSONDATA.documentData.userdata ? <div className="row mb-3">
        <div className="col-12">
            <div className="header_bottom">
                <ul className="d-flex mb-0 pl-0 justify-content-around unstyled">
                    <li className="d-flex">
                    <p className="mb-0">{MYJSONDATA.documentData.userdata[0].name}</p>
                    <p className="mb-0 pl-2">{MYJSONDATA.documentData.userdata[0].age}</p>
                    </li>
                    <li>ID : {MYJSONDATA.documentData.userdata[0].id}</li>
                    <li>
                        With 535158
                    </li>
                    <li>8 Weeks pragnant</li>
                    <li>LMP : <span>20/01/2020</span></li>
                    <li>EDD : <span>19/10/2020</span></li>
                </ul>
            </div>
        </div>
    </div> : null : null}
    </>
    )
}
export default HeaderBottom;