import logo from './logo.svg';
import './App.css';

import Header from './component/layout/Header'
import HeaderBottom from './component/layout/bottomheader'
import Graph from './component/screen/Graph'

function App() {
  return (
    <div className="container-fluid">
      <Header />
      <HeaderBottom />
      <Graph />
    </div>
  );
}

export default App;
