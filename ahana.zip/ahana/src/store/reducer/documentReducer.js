import * as actionType from '../constants/index'

const initialState = {
    loading : false,
    documentData : {},
    error : '' ,
    dataShow : []
}

export const documnetReducer = (state = initialState, action) => {
    switch(action.type){
        case actionType.FETCH_DATA_REQUEST :
            return{
                ...state,
                loading : true,
            }
        case actionType.FETCH_DATA_SUCCESS : 
        console.log(action.payload,"action.payload");
            return{
                loading : false,
                documentData : action.payload,
                dataShow : action.payload.newdata
            }
        case actionType.FETCH_DATA_FAIL : 
            return{
                loading : false,
                error : action.payload
            }
        default:
            return state
    }
}