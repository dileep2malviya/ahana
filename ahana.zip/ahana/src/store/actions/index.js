import axios from 'axios'

import {
    FETCH_DATA_REQUEST,
    FETCH_DATA_SUCCESS,
    FETCH_DATA_FAIL
} from '../constants/index'

export const dataRequest = () => {
    return{
        type : FETCH_DATA_REQUEST
    }
}
export const dataSuccess = (data) => {
    return{
        type : FETCH_DATA_SUCCESS,
        payload : data
    }
}
export const dataFail = () => {
    return{
        type : FETCH_DATA_FAIL
    }
}

export const fetchdata = () => {
    return (dispatch) => {
        dispatch(dataRequest());
        fetch("data/done.json")
            .then((response) => response.json())
            .then(function (myJson) {
                const myData = myJson;
                dispatch(dataSuccess(myData));
            })
            .catch((error) => {
                dispatch(dataFail(error.message));
            });
    };
};
